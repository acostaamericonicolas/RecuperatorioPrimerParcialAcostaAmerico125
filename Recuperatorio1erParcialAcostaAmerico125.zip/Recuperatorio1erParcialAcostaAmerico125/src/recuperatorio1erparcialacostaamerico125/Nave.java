
package recuperatorio1erparcialacostaamerico125;

import java.util.Objects;

public abstract class Nave {
    private String nombre;
    private int capacidadDeTripulacion;
    private int anioDeLanzamiento;

    public Nave(String nombre, int capacidadDeTripulación, int anioDeLanzamiento) {
        this.nombre = nombre;
        this.capacidadDeTripulacion = capacidadDeTripulacion;
        this.anioDeLanzamiento = anioDeLanzamiento;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + Objects.hashCode(this.nombre);
        hash = 17 * hash + this.anioDeLanzamiento;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nave other = (Nave) obj;
        if (this.anioDeLanzamiento != other.anioDeLanzamiento) {
            return false;
        }
        return Objects.equals(this.nombre, other.nombre);
    }
    
    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", capacidadDeTripulacion=" + capacidadDeTripulacion + ", anioDeLanzamiento=" + anioDeLanzamiento + '}';
    }
    
    
    
    
}
