
package recuperatorio1erparcialacostaamerico125;

public class NaveRepetidaException extends RuntimeException{
    private static final String MESSAGE = "!!!!!!!!!!!! La nave ya esta en el sistema !!!!!!!!!!!! ";
    
    public NaveRepetidaException(){
        super(MESSAGE);
    }
}

