package recuperatorio1erparcialacostaamerico125;

public interface Explorable {
    void iniciarExploracion();
}