package recuperatorio1erparcialacostaamerico125;

public enum TipoMision {
    CARTOGRAFÍA, 
    INVESTIGACIÓN, 
    CONTACTO
    
}
