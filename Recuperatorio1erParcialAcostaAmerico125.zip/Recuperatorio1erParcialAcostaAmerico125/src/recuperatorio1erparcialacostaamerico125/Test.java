package recuperatorio1erparcialacostaamerico125;

public class Test {

    public static void main(String[] args) {
        /*
        Se debe poder agregar un carguero llamado "Galáctica" con una capacidad de carga de 300
toneladas, y al intentar agregar otra nave con el mismo nombre y año de lanzamiento, se debe
lanzar una excepción.
        */
        Sistema naves = new Sistema();
        
        Carguero carguero = new Carguero("Galactica", 20, 2020, 300);
        Carguero carguero1 = new Carguero("Apolo", 10, 2021, 100);
        Carguero carguero2 = new Carguero("Galactica", 20, 2020, 100);
        CruceroEstelar crucero = new CruceroEstelar("Crucero Estelar", 5, 1990, 100);
        NaveExploracion naveEx = new NaveExploracion("Nave Explora", 10, 1800, TipoMision.CONTACTO);
        
        try {
        naves.agregarNave(carguero);
        naves.agregarNave(naveEx);
        naves.agregarNave(crucero);
        naves.agregarNave(carguero1);
        naves.agregarNave(carguero2);
        
        } catch(NaveRepetidaException ex){
            System.out.println(ex.getMessage());
        }
        
        System.out.println("------------");
        naves.mostrarNaves();
        System.out.println("------------");
        naves.iniciarExploracion();
        
        
    }
    
}
