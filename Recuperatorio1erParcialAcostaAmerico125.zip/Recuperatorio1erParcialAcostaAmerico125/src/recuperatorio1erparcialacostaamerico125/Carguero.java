package recuperatorio1erparcialacostaamerico125;

public class Carguero extends Nave implements Explorable{
    private final int CARGA_MAX=500;
    private final int CARGA_MIN=100;
    private final int capacidadCarga;

    public Carguero(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento, int capacidadCarga) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void iniciarExploracion() {
        System.out.println("Carguero iniciando exploracion");
    }

    @Override
    public String toString() {
        return super.toString() +"capacidadCarga=" + capacidadCarga + '}';
    }
    
    public boolean validarCarga(){
        return capacidadCarga >= CARGA_MIN && capacidadCarga <= CARGA_MAX;
    }
    
    
    
}
