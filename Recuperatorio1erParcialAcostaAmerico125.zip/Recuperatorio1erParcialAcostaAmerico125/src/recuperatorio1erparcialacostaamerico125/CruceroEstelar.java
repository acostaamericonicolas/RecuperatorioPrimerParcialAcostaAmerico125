package recuperatorio1erparcialacostaamerico125;

public class CruceroEstelar extends Nave{
    private final int cantidadPasajeros;

    public CruceroEstelar(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento, int cantidadPasajeros) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String toString() {
        return super.toString() +"cantidadPasajeros=" + cantidadPasajeros + '}';
    }
    
    

    
}
