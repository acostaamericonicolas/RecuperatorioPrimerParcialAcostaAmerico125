package recuperatorio1erparcialacostaamerico125;

public class NaveExploracion extends Nave implements Explorable{
    private TipoMision tipoMision;

    public NaveExploracion(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.tipoMision = tipoMision;
    }
   
    @Override
    public void iniciarExploracion() {
        System.out.println("Nave de exploracion iniciando exploracion");
    }

    @Override
    public String toString() {
        return super.toString() +"tipoMision=" + tipoMision + '}';
    }
    
    
}
