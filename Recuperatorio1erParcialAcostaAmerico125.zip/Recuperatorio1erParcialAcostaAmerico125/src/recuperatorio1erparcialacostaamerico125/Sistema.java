
package recuperatorio1erparcialacostaamerico125;

import java.util.ArrayList;
import java.util.List;

public class Sistema {
    private final List<Nave> naves;

    public Sistema() {
        this.naves = new ArrayList<>();
    }

    public void agregarNave(Nave nave)throws NaveRepetidaException{
        if (nave == null || naves.contains(nave)){
            throw new NaveRepetidaException();
        }
        if(nave instanceof Carguero &&!((Carguero) nave).validarCarga()){
            throw new NaveRepetidaException();
        }
        naves.add(nave);
    }

    public void mostrarNaves(){
        if(naves.isEmpty()){
            System.out.println("No hay naves");
        }
        else{
            for (Nave p : naves){
            System.out.println(p);
            }        
        } 
    }

    public void iniciarExploracion(){
        System.out.println("iniciando exploracion...\n");
        for(Nave nave : naves){
            if(nave instanceof Explorable explorable){
                explorable.iniciarExploracion();
            }
            else{
                System.out.println("La nave: " +nave.getNombre() + " !!!NO!!! puede participar en misiones.");
            }
                
        }
    }
    
}
